﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для Meropr.xaml
    /// </summary>
    public partial class Meropr : Page
    {
        public Meropr()
        {
            InitializeComponent();
            DGridMain.ItemsSource = pepeEntities.GetContext().Event.ToList();
            //ImportPhoto();
        }

        private void btnToAdd(object sender, RoutedEventArgs e)
        {

        }

        private void btnToBack(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();

        }
        private void ImportPhoto()
        {
            var images = Directory.GetFiles(@"C:\Users\isp11\OneDrive\Рабочий стол\дэ свежее\Ресурсы\Мероприятия_import");
            var events = pepeEntities.GetContext().Event.ToList();
            foreach (Event i in events)
            {
                try
                {
                    i.photo = File.ReadAllBytes(images.FirstOrDefault(p => p.Contains(i.id.ToString())));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
                pepeEntities.GetContext().SaveChanges();
            }
        }
    }
}
