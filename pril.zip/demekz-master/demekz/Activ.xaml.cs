﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для Activ.xaml
    /// </summary>
    public partial class Activ : Page
    {
        public Activ()
        {
            InitializeComponent();
            DGridActiv.ItemsSource = pepeEntities.GetContext().Activity.ToList();
        }

        private void btnToAdd(object sender, RoutedEventArgs e)
        {

        }

        private void btnToBack(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();

        }
    }
}
