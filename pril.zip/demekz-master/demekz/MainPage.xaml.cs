﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
       
        public MainPage()
        {
            InitializeComponent();
            UpdateGreeting();
            TypeMan();
            PhotoPep();
            Kto();
        }
        private void PhotoPep()
        {
            byte[] photoBytes = Manager.CurrentUser.photo;

            // Создать объект BitmapImage
            BitmapImage bitmapImage = new BitmapImage();

            // Загрузить изображение из массива байтов
            using (MemoryStream memoryStream = new MemoryStream(photoBytes))
            {
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = memoryStream;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
            }

            // Создать элемент Image
            Image image = new Image();
            image.Source = bitmapImage;
            PhotoPPPP.Source = bitmapImage;
        }
        private void Kto()
        {
            var kto = Manager.CurrentUser.gender;
            var imya = Manager.CurrentUser.first_name;
            var otchestvo = Manager.CurrentUser.last_name;

            if (kto == "ж") LabelKto.Content = $"Миссис {imya} {otchestvo} ";
            else LabelKto.Content = $"Мистер {imya} {otchestvo}";
        }


        private void UpdateGreeting()
        {
            int currentHour = DateTime.Now.Hour;
            if (currentHour >= 0 && currentHour < 12)
            {
                LabelGo.Content = "Доброе утро!";
            }
            else if (currentHour >= 12 && currentHour < 20)
            {
                LabelGo.Content = "Добрый день!";
            }
            else
            {
                LabelGo.Content = "Добрый вечер!";
            }
        }
        private void TypeMan()
        {
            
           int typeMan = Manager.CurrentUser.id_role;
            if(typeMan == 1)
            {
                LabelType.Content = "Окно организатора";
                Activ.Visibility = Visibility.Hidden;
            }
            else if (typeMan == 2)
            {
                LabelType.Content = "Окно жюри";
                Meropr.Visibility = Visibility.Hidden;
                Juri.Visibility = Visibility.Hidden;
                People.Visibility = Visibility.Hidden;
            }
            else if (typeMan == 3)
            {
                LabelType.Content = "Окно участника";
                Meropr.Visibility = Visibility.Hidden;
                Juri.Visibility = Visibility.Hidden;
                People.Visibility = Visibility.Hidden;
            }
            else
            {
                LabelType.Content = "Окно модератора";
                Juri.Visibility = Visibility.Hidden;
                People.Visibility = Visibility.Hidden;
                Activ.Visibility = Visibility.Hidden;

            }
        }

        private void btnToJuri(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Juri());
        }

        private void btnToPeople(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new People());

        }

        private void btnToActiv(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Activ());

        }

        private void btnToMeropr(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Meropr());

        }

        private void btnToBack(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }

        private void btnToInfoProfile(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new UserProfile());
        }
    }
}
