﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xceed.Wpf.Toolkit;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для AddPage.xaml
    /// </summary>
    public partial class AddPage : Page
    {
        string q;
        public AddPage()
        {
            InitializeComponent();
            
            List <Role> roles = pepeEntities.GetContext().Role.ToList();
            List <Event> events = pepeEntities.GetContext().Event.ToList();
            IdPlus();
            roleBox.ItemsSource = roles;
            eventsBox.ItemsSource = events;
        }
        private void IdPlus()
        {
            var numUser = pepeEntities.GetContext().User.ToList();
            int userID = numUser[numUser.Count - 1].id + 1;
            TextId.Text = $"{userID}";
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CheckPassword();
        }
        private void CheckPassword()
        {
            if (string.IsNullOrEmpty(PassTextBox.Password) || string.IsNullOrEmpty(DoublePassword.Password))
            {
                System.Windows.MessageBox.Show("Какое-то поле пустое!");
            }
            else
            {
                if (PassTextBox.Password == DoublePassword.Password)
                {
                    System.Windows.MessageBox.Show("Одинаковый!");

                }
                else
                {
                    System.Windows.MessageBox.Show("Пароль не одинаковый!");
                }
            }
        }

        private void btnToBack(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.GoBack();
        }
    }
}
