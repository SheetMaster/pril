﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace demekz
{
    /// <summary>
    /// Логика взаимодействия для Captcha.xaml
    /// </summary>
    public partial class Captcha : Page
    {
        public Captcha()
        {
            InitializeComponent();
            GenerateCaptcha();
        }
        
        private void GenerateCaptcha()
        {
            Random rand = new Random();
            int symbols = rand.Next(6, 8);
            int angel = rand.Next(-10, 20);
            RotateTransform rotate = new RotateTransform(angel);
            CaptchaText.RenderTransform = rotate;
            string captcha = "";
            int totalchar = 0;
            do
            {
                int chr = rand.Next(48, 123);
                if((chr >= 33 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    totalchar++;
                    if (totalchar == symbols) break;
                }
            }
            while (true);
            CaptchaText.Text = captcha;
            
        }

        private void btnToLogin(object sender, RoutedEventArgs e)
        {
            
            string ex = "Неправильно!";
            if (EntCaptcha.Text == CaptchaText.Text)
            {
                MessageBox.Show("Успешный ввод капчи!");
                Manager.MainFrame.Navigate(new Auth());
            }
            else
            {
                MessageBox.Show(ex);
                GenerateCaptcha();
            }
        }

        private void btnToReload(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }
    }
}
